/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package com.mycompany.quickchatapp2;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

/**
 *
 * @author USER
 */
public class MessageTest {
    
  @Before
    public void setup() {
        // Clear arrays before each test
        Message.sentMessages.clear();
        Message.storedMessages.clear();
        Message.disregardedMessages.clear();
        
    }

    @Test
    public void testSentMessagesPopulation() {
        Message msg1 = new Message("+27834557896", "Did you get the cake?", "sent");
        Message msg4 = new Message("0838884567", "It is dinner time !", "sent");

        Message.addSentMessage(msg1);
        Message.addSentMessage(msg4);

        List<Message> sent = Message.sentMessages;

        assertEquals(2, sent.size());
        assertEquals("Did you get the cake?", sent.get(0).messageContent);
        assertEquals("It is dinner time !", sent.get(1).messageContent);
    }

    @Test
    public void testLongestSentMessage() {
        Message.addSentMessage(new Message("+27834557896", "Short", "sent"));
        Message.addSentMessage(new Message("+27838884567", "Where are you? You are late! I have asked you to be on time.", "sent"));
        String longest = Message.getLongestSentMessage();
        assertTrue(longest.contains("Where are you?"));
        
    }

    @Test
    public void testSearchMessageByID() {
        Message msg = new Message("0838884567", "It is dinner time !", "sent");
        Message.addSentMessage(msg);
        String output = Message.searchByMessageID(msg.messageID);
        assertTrue(output.contains("It is dinner time"));
      
    }

    @Test
    public void testSearchMessagesByRecipient() {
        Message msg1 = new Message("+27838884567", "Where are you? You are late! I have asked you to be on time.", "stored");
        Message msg2 = new Message("+27838884567", "Ok, I am leaving without you.", "stored");

        Message.addStoredMessage(msg1);
        Message.addStoredMessage(msg2); 

        String result = Message.searchMessagesByRecipient("+27838884567");
        assertTrue(result.contains("Where are you?"));
        assertTrue(result.contains("Ok, I am leaving without you."));
    }

    @Test
    public void testDeleteByHash() {
        Message.clearStoredMessages(); 
        Message msg = new Message("+27838884567", "Where are you? You are late! I have asked you to be on time.", "stored");
        Message.addStoredMessage(msg);

        String result = Message.deleteMessageByHash(msg.messageHash);
        assertEquals("Message \"Where are you? You are late! I have asked you to be on time.\" successfully deleted.", result);
    }

    @Test
    public void testGenerateReport() {
        Message msg = new Message("+27834557896", "Did you get the cake?", "sent");
        Message.addSentMessage(msg);
        String report = Message.generateReport();
        assertTrue(report.contains("Message Hash"));
        assertTrue(report.contains(msg.messageHash));
    }
}

