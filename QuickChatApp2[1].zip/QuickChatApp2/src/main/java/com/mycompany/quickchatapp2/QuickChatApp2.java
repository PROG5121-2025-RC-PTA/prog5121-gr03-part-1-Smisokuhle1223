/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.quickchatapp2;
import javax.swing.*;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author USER
 */
public class QuickChatApp2 {

   static String username = "";
static String password = "";
static boolean userIsLoggedIn = false;
static int totalMessagesSent = 0;

public static void main(String[] args) {

    JOptionPane.showMessageDialog(null, "Welcome to QuickChat.");
    int userChoice = JOptionPane.showOptionDialog(null, "Choose an option:", "QuickChat",
            JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null,
            new String[]{"Sign Up", "Login"}, "Sign Up");

    if (userChoice == 0) {
        performUserSignUp();
    } else {
        performUserLogin();
    }

    if (!userIsLoggedIn) {
        JOptionPane.showMessageDialog(null, "Login failed. Exiting application.");
        return;
    }

    int maximumNumberOfMessages = Integer.parseInt(JOptionPane.showInputDialog("How many messages would you like to send?"));
    int currentMessageCount = 0;

    while (true) {
        String[] menuOptions = {
                "Send Message", "Show Sent Messages", "Show Longest Sent Message",
                "Search Message by ID", "Search Messages by Recipient",
                "Delete Message by Hash", "Show Message Report", "Quit"
        };
        int selectedOption = JOptionPane.showOptionDialog(null, "Select an option:", "Main Menu",
                JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null,
                menuOptions, menuOptions[0]);

        switch (selectedOption) {
            case 0 -> {
                if (currentMessageCount < maximumNumberOfMessages) {
                    Message newMessage = new Message();
                    newMessage.createAndValidateMessage();

                    switch (newMessage.messageStatus) {
                        case "sent" -> {
                            totalMessagesSent++;
                            currentMessageCount++;
                            Message.addSentMessage(newMessage);
                            newMessage.displayMessageDetails();
                        }
                        case "stored" -> {
                            currentMessageCount++;
                            saveMessageToJSON(newMessage);
                            Message.addStoredMessage(newMessage);
                        }
                        case "disregarded" -> {
                            currentMessageCount++;
                            Message.addDisregardedMessage(newMessage);
                        }
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Message limit has been reached.");
                }
            }
            case 1 -> JOptionPane.showMessageDialog(null, Message.displaySenderAndRecipients());
            case 2 -> JOptionPane.showMessageDialog(null, Message.getLongestSentMessage());
            case 3 -> {
                String id = JOptionPane.showInputDialog("Enter message ID:");
                JOptionPane.showMessageDialog(null, Message.searchByMessageID(id));
            }
            case 4 -> {
                String recipient = JOptionPane.showInputDialog("Enter recipient number:");
                JOptionPane.showMessageDialog(null, Message.searchMessagesByRecipient(recipient));
            }
            case 5 -> {
                String hash = JOptionPane.showInputDialog("Enter message hash to delete:");
                JOptionPane.showMessageDialog(null, Message.deleteMessageByHash(hash));
            }
            case 6 -> JOptionPane.showMessageDialog(null, Message.generateReport());
            case 7, -1 -> {
                JOptionPane.showMessageDialog(null, "You sent a total of " + totalMessagesSent + " messages.");
                return;
            }
        }
    }
}

public static void performUserSignUp() {
    username = JOptionPane.showInputDialog("Choose a username:");
    password = JOptionPane.showInputDialog("Choose a password:");
    JOptionPane.showMessageDialog(null, "Now please login to continue.");
    performUserLogin();
}

public static void performUserLogin() {
    String enteredUsername = JOptionPane.showInputDialog("Enter username:");
    String enteredPassword = JOptionPane.showInputDialog("Enter password:");
    userIsLoggedIn = enteredUsername.equals(username) && enteredPassword.equals(password);
}

public static void saveMessageToJSON(Message messageObject) {
    try (FileWriter fileWriter = new FileWriter("stored_messages.json", true)) {
        String jsonFormattedMessage = "{" +
                "\"messageID\":\"" + messageObject.messageID +
                "\",\"hash\":\"" + messageObject.messageHash +
                "\",\"recipient\":\"" + messageObject.recipientNumber +
                "\",\"message\":\"" + messageObject.messageContent +
                "\",\"status\":\"" + messageObject.messageStatus + "\"}";
        fileWriter.write(jsonFormattedMessage + System.lineSeparator());
    } catch (IOException exception) {
        JOptionPane.showMessageDialog(null, "Unable to store the message.");
    }
}
}

