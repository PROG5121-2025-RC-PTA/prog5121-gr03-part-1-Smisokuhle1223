/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quickchatapp2;
import java.util.ArrayList;
import java.util.Random;
/**
 *
 * @author USER
 */
public class Message {

    // Existing variables
    public String messageID;
    public String messageHash;
    public String recipientNumber;
    public String messageContent;
    public String messageStatus;
    
    public Message(String recipient, String content, String status) {
        this.messageID = generateMessageID();
        this.recipientNumber = recipient;
        this.messageContent = content;
        this.messageStatus = status;
        this.messageHash = generateMessageHash();     
    }
    
   
    public static void main(String[] args) {       
    }

    Message() {
        throw new UnsupportedOperationException("Not supported yet."); 
    }
    
    // Code to generate ID, validate recipient, and message
    public void createAndValidateMessage(){
}
   static ArrayList<Message> sentMessages = new ArrayList<>();
    static ArrayList<Message> storedMessages = new ArrayList<>();
    static ArrayList<Message> disregardedMessages = new ArrayList<>();

    public static void addSentMessage(Message message) {
        sentMessages.add(message);
    }

    public static void addStoredMessage(Message message) {
        storedMessages.add(message);
    }

    public static void addDisregardedMessage(Message message) {
        disregardedMessages.add(message);
    }
    public static void clearStoredMessages() {
        storedMessages.clear();
    }
    public static String displaySenderAndRecipients() {
        StringBuilder sb = new StringBuilder("Sender and Recipient Details:\n");
        for (Message m : sentMessages) {
            sb.append("Sender: ").append("You").append(", Recipient: ").append(m.recipientNumber).append("\n");
        }
        return sb.toString();
    }

    public static String getLongestSentMessage() {
        String longest = "";
        for (Message m : sentMessages) {
            if (m.messageContent.length() > longest.length()) {
                longest = m.messageContent;
            }
        }
        return longest.isEmpty() ? "No sent messages." : "Longest Sent Message:\n" + longest;
    }

    public static String searchByMessageID(String id) {
        for (Message m : sentMessages) {
            if (m.messageID.equals(id)) {
                return "Found Message:\nRecipient: " + m.recipientNumber + "\nMessage: " + m.messageContent;
            }
        }
        return "No message found with ID: " + id;
    }

    public static String searchMessagesByRecipient(String recipient) {
        StringBuilder result = new StringBuilder();
        for (Message m : sentMessages) {
            if (m.recipientNumber.equals(recipient)) {
                result.append(m.messageContent).append("\n");
            }
        }
        for (Message m : storedMessages) {
            if (m.recipientNumber.equals(recipient)) {
                result.append(m.messageContent).append("\n");
            }
        }
        return result.length() > 0 ? result.toString() : "No messages found for recipient: " + recipient;
    }

    public static String deleteMessageByHash(String hash) {
        for (Message m : sentMessages) {
            if (m.messageHash.equals(hash)) {
                sentMessages.remove(m);
                return "Message \"" + m.messageContent + "\" successfully deleted.";
            }
        }
        return "No message found with hash: " + hash;
    }

    public static String generateReport() {
        StringBuilder report = new StringBuilder("=== Sent Messages Report ===\n");
        for (Message m : sentMessages) {
            report.append("Message Hash: ").append(m.messageHash).append("\n");
            report.append("Recipient: ").append(m.recipientNumber).append("\n");
            report.append("Message: ").append(m.messageContent).append("\n");
            report.append("----\n");
        }
        return report.toString();
    }
    public String generateMessageID() {
    return String.valueOf(new Random().nextInt(900000000) + 100000000); // 9-digit ID
}

public String generateMessageHash() {
    String[] words = messageContent.split(" ");
    String first = words.length > 0 ? words[0].toUpperCase() : "EMPTY";
    String last = words.length > 1 ? words[words.length - 1].toUpperCase() : first;
    return messageID.substring(0, 2) + ":" + first + last;
}

    public void displayMessageDetails(){
          System.out.println("Message ID: " + messageID);
          System.out.println("Hash: " + messageHash);
          System.out.println("Recipient: " + recipientNumber);
          System.out.println("Message: " + messageContent);
          System.out.println("Status: " + messageStatus);
    }
    public static ArrayList<Message> getSentMessages() {
        return sentMessages;
    }

    public static ArrayList<Message> getStoredMessages() {
        return storedMessages;
    }

    public static ArrayList<Message> getDisregardedMessages() {
        return disregardedMessages;
    }public String getMessageID() {
    return messageID;
}

public String getMessageHash() {
    return messageHash;
}

public String getRecipientCellNumber() {
    return recipientNumber;
}

public String getMessageContent() {
    return messageContent;
}

public String getMessageStatus() {
    return messageStatus;
}

}