/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quickchatapp2;
import javax.swing.*;
import java.util.Random;
/**
 *
 * @author USER
 */
public class Message {
    public static void main(String[] args) {
}
 public String messageID;
    public String recipientCellNumber;
    public String messageContent;
    public String messageHash;
    public String messageStatus = "";

    // Method to create a message and validate input fields
    public void createAndValidateMessage() {
        messageID = generateMessageID();

        while (true) {
            recipientCellNumber = JOptionPane.showInputDialog("Enter recipient cell number (include +):");
            if (isRecipientCellNumberValid(recipientCellNumber)) {
                break;
            }
            JOptionPane.showMessageDialog(null, "Invalid number. It must start with '+27' and be 13 characters or fewer.");
        }

        messageContent = JOptionPane.showInputDialog("Enter your message (maximum 250 characters):");

        if (isMessageContentLengthValid(messageContent)) {
            JOptionPane.showMessageDialog(null, "Message is ready to send.");
        } else {
            JOptionPane.showMessageDialog(null, "Your message exceeds the 250 character limit by " + (messageContent.length() - 250) + " characters.");
            return;
        }

        messageHash = generateMessageHash();

        String[] messageActionOptions = {"Send Message", "Disregard Message", "Store Message"};
        int selectedAction = JOptionPane.showOptionDialog(null, "Choose an action for this message:", "Message Options",
                JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null,
                messageActionOptions, messageActionOptions[0]);

        if (selectedAction == 0) {
            messageStatus = "sent";
            JOptionPane.showMessageDialog(null, "Message successfully sent.");
        } else if (selectedAction == 1) {
            messageStatus = "disregarded";
            JOptionPane.showMessageDialog(null, "Message has been disregarded. Press 0 to delete.");
        } else if (selectedAction == 2) {
            messageStatus = "stored";
        }
    }

    // Method to generate a random 9-digit message ID
    public String generateMessageID() {
        Random randomGenerator = new Random();
        int randomNumber = 100000000 + randomGenerator.nextInt(900000000);
        return String.valueOf(randomNumber);
    }

    // Method to validate if a cell number is correct (starts with +27 and ≤ 13 characters)
    public boolean isRecipientCellNumberValid(String cellNumber) {
        if (cellNumber == null) {
            return false;
        }
        return cellNumber.startsWith("+27") && cellNumber.length() <= 13;
    }

    // Method to validate message length
    public boolean isMessageContentLengthValid(String messageText) {
        return messageText != null && messageText.length() <= 250;
    }

    // Method to generate a simple message hash without using arrays
    public String generateMessageHash() {
        String firstWord = "";
        String lastWord = "";

        int firstSpaceIndex = messageContent.indexOf(" ");
        int lastSpaceIndex = messageContent.lastIndexOf(" ");

        if (firstSpaceIndex == -1 || lastSpaceIndex == -1 || firstSpaceIndex == lastSpaceIndex) {
            firstWord = messageContent.toUpperCase();
            lastWord = messageContent.toUpperCase();
        } else {
            firstWord = messageContent.substring(0, firstSpaceIndex).toUpperCase();
            lastWord = messageContent.substring(lastSpaceIndex + 1).toUpperCase();
        }

        return messageID.substring(0, 2) + ":" + QuickChatApp2.totalMessagesSent + ":" + firstWord + lastWord;
    }

    // Method to display the details of the message
    public void displayMessageDetails() {
        JOptionPane.showMessageDialog(null,
                "Message ID: " + messageID +
                "\nMessage Hash: " + messageHash +
                "\nRecipient: " + recipientCellNumber +
                "\nMessage Content: " + messageContent);
    }

    // Method to return a summary of the message (non-UI version for testing or logging)
    public String getMessageSummary() {
        return "ID: " + messageID + " | To: " + recipientCellNumber + " | Status: " + messageStatus;
    }

    // Method to return JSON representation of the message (for testing or storage)
        //  OpenAI. (2023). ChatGPT (Mar 14 version)
    public String getMessageAsJsonString() {
        return "{" +
                "\"messageID\":\"" + messageID + "\"," +
                "\"hash\":\"" + messageHash + "\"," +
                "\"recipient\":\"" + recipientCellNumber + "\"," +
                "\"message\":\"" + messageContent + "\"," +
                "\"status\":\"" + messageStatus + "\"" +
                "}";
    }
    public void createAndValidateMessageForTest(String testRecipientNumber, String testMessageContent, int selectedAction) {
    messageID = generateMessageID();
    recipientCellNumber = testRecipientNumber;
    messageContent = testMessageContent;

    if (!isRecipientCellNumberValid(recipientCellNumber)) {
        messageStatus = "invalid";
        return;
    }

    if (messageContent.length() > 250) {
        messageStatus = "too long";
        return;
    }

    messageHash = generateMessageHash();

    if (selectedAction == 0) {
        messageStatus = "sent";
    } else if (selectedAction == 1) {
        messageStatus = "disregarded";
    } else if (selectedAction == 2) {
        messageStatus = "stored";
    } else {
        messageStatus = "invalid option";
    }
}


}

 

