/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.quickchatapp2;
import javax.swing.*;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author USER
 */
public class QuickChatApp2 {

    static String username = "";
    static String password = "";
    static boolean userIsLoggedIn = false;
    static int totalMessagesSent = 0;

    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "Welcome to QuickChat.");

        int userChoice = JOptionPane.showOptionDialog(null, "Choose an option:", "QuickChat",
                JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null,
                new String[]{"Sign Up", "Login"}, "Sign Up");

        if (userChoice == 0) {
            performUserSignUp();
        } else {
            performUserLogin();
        }

        if (!userIsLoggedIn) {
            JOptionPane.showMessageDialog(null, "Login failed. Exiting application.");
            return;
        }

        int numberOfMessagesAllowed = Integer.parseInt(
                JOptionPane.showInputDialog("How many messages would you like to send?"));
        int currentMessageCount = 0;

        while (true) {
            int menuSelection = JOptionPane.showOptionDialog(null, "Select an option:", "Main Menu",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null,
                    new String[]{"Send Message", "Show Recently Sent Messages", "Quit"}, "Send Message");

            if (menuSelection == 0 && currentMessageCount < numberOfMessagesAllowed) {
                Message newMessage = new Message();
                newMessage.createAndValidateMessage();

                if (newMessage.messageStatus.equals("sent")) {
                    totalMessagesSent++;
                    currentMessageCount++;
                    newMessage.displayMessageDetails();
                } else if (newMessage.messageStatus.equals("stored")) {
                    storeMessageInJSONFile(newMessage);
                    currentMessageCount++;
                }

            } else if (menuSelection == 1) {
                JOptionPane.showMessageDialog(null, "Coming Soon.");
            } else if (menuSelection == 2) {
                break;
            } else if (currentMessageCount >= numberOfMessagesAllowed) {
                JOptionPane.showMessageDialog(null, "Message limit reached.");
            }
        }

        JOptionPane.showMessageDialog(null, "Total messages sent: " + totalMessagesSent);
    }

    public static void performUserSignUp() {
        username = JOptionPane.showInputDialog("Choose a username:");
        password = JOptionPane.showInputDialog("Choose a password:");
        JOptionPane.showMessageDialog(null, "Please log in now.");
        performUserLogin();
    }

    public static void performUserLogin() {
        String enteredUsername = JOptionPane.showInputDialog("Enter username:");
        String enteredPassword = JOptionPane.showInputDialog("Enter password:");
        userIsLoggedIn = enteredUsername.equals(username) && enteredPassword.equals(password);
    }

        //  OpenAI. (2023). ChatGPT (Mar 14 version)
    public static void storeMessageInJSONFile(Message messageObject) {
        try (FileWriter fileWriter = new FileWriter("stored_messages.json", true)) {
            String jsonMessage = "{"
                    + "\"messageID\":\"" + messageObject.messageID + "\","
                    + "\"hash\":\"" + messageObject.messageHash + "\","
                    + "\"recipient\":\"" + messageObject.recipientCellNumber + "\","
                    + "\"message\":\"" + messageObject.messageContent + "\","
                    + "\"status\":\"" + messageObject.messageStatus + "\"}";
            fileWriter.write(jsonMessage + System.lineSeparator());
            JOptionPane.showMessageDialog(null, "Message stored successfully.");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Failed to store message.");
        }
    }
}

