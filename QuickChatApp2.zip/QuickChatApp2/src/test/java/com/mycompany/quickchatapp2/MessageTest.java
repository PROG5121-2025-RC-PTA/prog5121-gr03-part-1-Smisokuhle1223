/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package com.mycompany.quickchatapp2;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author USER
 */
public class MessageTest {
    
    public MessageTest() {
    }


    @Test
    public void testGenerateMessageID() {
        Message message = new Message();
        String id = message.generateMessageID();
        assertEquals(9, id.length()); 
    }

    @Test
    public void testIsRecipientCellNumberValid() {
        Message message = new Message();
        assertTrue(message.isRecipientCellNumberValid("+27123456789"));  
        assertFalse(message.isRecipientCellNumberValid("0812345678"));  
        assertFalse(message.isRecipientCellNumberValid("+2712345678901")); 
    }

    @Test
    public void testIsMessageContentLengthValid() {
        Message message = new Message();
        message.messageContent = "This is a valid message.";
        // Ensure the message lenght is at most 250 characters
        assertTrue(message.messageContent.length()<=250);
        // Create a message that exceeds the limit using String.repeat()
        message.messageContent = "x".repeat(251);
        assertTrue(message.messageContent.length()>250);
        
    }

    @Test
    public void testGenerateMessageHash() {
          Message message = new Message();
          message.messageContent = "Hi Mike, can you join us for dinner tonight";
          message.messageID = "0012345678";
          // Set totalMessagesSent from QuickChatApp2 to known value for testing
          QuickChatApp2.totalMessagesSent = 0;
          String expectedHash = "00:0:HITONIGHT";
          assertEquals(expectedHash, message.generateMessageHash());
    }

    @Test
    public void testDisplayMessageDetails() {
        Message message = new Message();
        message.messageID = "111111111";
        message.messageHash = "11:0:HELLOWORLD";
        message.recipientCellNumber = "+27123456789";
        message.messageContent = "Hello world";
        // Just ensuring no exceptions thrown when displaying
        message.displayMessageDetails();
   
    }
    @Test
    public void testInvalidRecipient_DiscardedMessage() {
        Message message = new Message();

        String recipient = "08575975889";
        String content = "Hi Keegan, did you receive the payment?";
        int action = 1; // Disregard

        message.createAndValidateMessageForTest(recipient, content, action);

        assertEquals("invalid", message.messageStatus);
    }
}
    

